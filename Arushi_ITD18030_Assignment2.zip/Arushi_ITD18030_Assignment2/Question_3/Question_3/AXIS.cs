﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_3
{
    class AXIS : Bank
    {
        double Bank.getRateOfInterest(double Pamount, double time)
        {
            double Famount = (Pamount * time * 9) / 100;
            return Famount;
        }
    }
}
